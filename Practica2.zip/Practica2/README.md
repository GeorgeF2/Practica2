# Practica2
Este codigo corre en java para ver si un 'w' pertenece a un lenguaje
